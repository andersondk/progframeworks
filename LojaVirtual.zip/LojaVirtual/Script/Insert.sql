INSERT INTO pessoa (pes_nome, pes_cpf, pes_rg, pes_data_nasc, pes_rua, pes_bairro, pes_cidade, pes_uf, pes_cep, pes_email, pes_senha, pes_tipo)
	VALUES ('Admininistrador', '32165498771', '1593574', '1991-12-19', 'Rua S 23 n 654 apt 201', 'Setor Sul', 'Goiânia', 'Go', '74000000', 'admin@admin', 'admin', 'ROLE_ADMINISTRADOR');

INSERT INTO pessoa (pes_nome, pes_cpf, pes_rg, pes_data_nasc, pes_rua, pes_bairro, pes_cidade, pes_uf, pes_cep, pes_email, pes_senha, pes_tipo)
	VALUES ('Cliente', '78965412328', '8523641', '1991-06-05', 'Rua 9 qd 23 lt 13', 'Setor Oeste', 'Goiânia', 'Go', '74000000', 'cliente@cliente', 'cliente', 'ROLE_CLIENTE');

INSERT INTO produto (prod_nome, prod_preco, prod_fabricante, prod_descricao, prod_qtd)
	VALUES ('Boneco Vegeta Super Sayajin : Dragon Ball Z (P.C.E) S.H Figuarts', '200', 'Bandai', 'Boneco', '15');

INSERT INTO produto (prod_nome, prod_preco, prod_fabricante, prod_descricao, prod_qtd)
	VALUES ('Estátua Goku Black Super Saiyan Rosé: Dragon Ball Super (Son Gokou Fes)', '287', 'Branpresto', 'Estátua', '20');
	
INSERT INTO produto (prod_nome, prod_preco, prod_fabricante, prod_descricao, prod_qtd)
	VALUES ('Dragon Ball Super Mega World Collectible: Shenglon', '180', 'Branpresto', 'Estátua', '5');